core-toolbar
============

See the [component page](http://polymer-project.org/docs/elements/core-elements.html#core-toolbar) for more information.
