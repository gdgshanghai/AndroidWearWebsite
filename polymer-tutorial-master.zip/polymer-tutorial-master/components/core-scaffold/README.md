core-scaffold
=============

See the [component page](http://polymer-project.org/docs/elements/core-elements.html#core-scaffold) for more information.
