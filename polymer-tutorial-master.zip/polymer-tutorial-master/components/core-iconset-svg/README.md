core-iconset-svg
=========

See the [component page](http://polymer-project.org/docs/elements/core-elements.html#core-iconset-svg) for more information.
