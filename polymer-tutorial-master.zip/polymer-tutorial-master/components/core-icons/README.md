core-icons
=========

See the [component page](http://polymer-project.org/docs/elements/core-elements.html#core-icons) for more information.
